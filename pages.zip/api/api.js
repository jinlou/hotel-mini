import axios from "./axios.js"
export default {
	idLogin (params){
		return axios.httpRequest({
			url: '/tourist/login-loginid',
		}, params)
	},
	
	wxLogin (params){
		return axios.httpRequest({
			url: 'tourist/login-wx'
		}, params)
	}
}